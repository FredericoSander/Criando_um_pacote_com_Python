# data_analisys

Description.
The package imagem_processing is used to:
    processing:
        - head
        - describe
        - info
        - nunique

## Installation 

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

'''bash
pip install data_analisys

python
from data_analisys.util import read
'''
## Autor
 Frederico S N Cota

 ## License

 [MIT](https://choosealicense.com/license/mit/)